"""FloodGuard AI — Backend API"""
