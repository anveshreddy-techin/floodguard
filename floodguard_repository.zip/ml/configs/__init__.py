"""ML pipeline configuration parameters."""
